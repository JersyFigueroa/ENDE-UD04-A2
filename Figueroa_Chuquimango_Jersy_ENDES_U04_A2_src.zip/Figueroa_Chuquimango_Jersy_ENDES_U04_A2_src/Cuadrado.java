package figuras;

import java.awt.Color;

/**
 * Clase que representa un cuadrado.
 * 
 * @author JersyFigueroa
 */
public class Cuadrado extends Figura {

    /** Lado del cuadrado */
    private double lado;

    /**
     * Constructor del cuadrado.
     * 
     * @param x centro X
     * @param y centro Y
     * @param color color
     * @param lado longitud del lado
     */
    public Cuadrado(double x, double y, Color color, double lado) {
        super(x, y, color);
        this.lado = lado;
    }

    /**
     * Calcula el área.
     */
    public double área() {
        return lado * lado;
    }

    /**
     * Calcula el perímetro.
     */
    public double perímetro() {
        return 4 * lado;
    }
}
