package figuras;

import java.awt.Color;

/**
 * Clase abstracta que representa una figura geométrica.
 * Define atributos comunes como el centro y el color.
 * Las clases hijas deben implementar área y perímetro.
 * 
 * @author JersyFigueroa
 */
public abstract class Figura {

    /** Centro de la figura */
    private Punto centro;

    /** Color de la figura */
    private Color color;

    /**
     * Constructor de la clase Figura.
     * 
     * @param x coordenada X del centro
     * @param y coordenada Y del centro
     * @param color color de la figura
     */
    public Figura(double x, double y, Color color) {
        centro = new Punto(x, y);
        this.color = color;
    }

    /**
     * Obtiene la coordenada X del centro.
     * @return coordenada X
     */
    public double getXCentro() {
        return centro.getX();
    }

    /**
     * Obtiene la coordenada Y del centro.
     * @return coordenada Y
     */
    public double getYCentro() {
        return centro.getY();
    }

    /**
     * Obtiene el color de la figura.
     * @return color
     */
    public Color getColor() {
        return color;
    }

    /**
     * Modifica la coordenada X del centro.
     * @param x nueva coordenada
     */
    public void setXCentro(double x) {
        centro.setX(x);
    }

    /**
     * Modifica la coordenada Y del centro.
     * @param y nueva coordenada
     */
    public void setYCentro(double y) {
        centro.setY(y);
    }

    /**
     * Modifica el color.
     * @param color nuevo color
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Calcula el perímetro.
     * @return perímetro
     */
    public abstract double perímetro();

    /**
     * Calcula el área.
     * @return área
     */
    public abstract double área();

    /**
     * Compara el área con otra figura.
     * @param otraFigura figura a comparar
     * @return 1 si mayor, -1 si menor, 0 si iguales
     */
    public int esMayorQue(Figura otraFigura) {
        if (this.área() > otraFigura.área()) return 1;
        if (this.área() < otraFigura.área()) return -1;
        return 0;
    }
}
