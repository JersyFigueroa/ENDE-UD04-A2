package figuras;

import java.awt.Color;

/**
 * Clase de prueba para figuras.
 * Permite comprobar el funcionamiento del programa.
 * 
 * @author JersyFigueroa
 */
public class PruebaFigura {

    /**
     * Método principal.
     * @param args argumentos
     */
    public static void main(String[] args) {

        Cuadrado c = new Cuadrado(0, 0, Color.RED, 5);
        Rectangulo r = new Rectangulo(0, 0, Color.BLUE, 4, 6);
        Triángulo t = new Triángulo(0, 0, Color.GREEN, 3, 4, 5);

        System.out.println("Área cuadrado: " + c.área());
        System.out.println("Área rectángulo: " + r.área());
        System.out.println("Área triángulo: " + t.área());
    }
}
