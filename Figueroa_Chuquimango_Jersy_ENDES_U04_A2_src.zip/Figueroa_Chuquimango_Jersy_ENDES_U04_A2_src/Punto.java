package figuras;

/**
 * Clase que representa un punto en el plano cartesiano.
 * 
 * @author JersyFigueroa
 */
public class Punto {

    /** Coordenada X */
    private double x;

    /** Coordenada Y */
    private double y;

    /**
     * Constructor del punto.
     * @param x coordenada X
     * @param y coordenada Y
     */
    public Punto(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Obtiene X.
     * @return valor X
     */
    public double getX() {
        return x;
    }

    /**
     * Obtiene Y.
     * @return valor Y
     */
    public double getY() {
        return y;
    }

    /**
     * Modifica X.
     * @param x nuevo valor
     */
    public void setX(double x) {
        this.x = x;
    }

    /**
     * Modifica Y.
     * @param y nuevo valor
     */
    public void setY(double y) {
        this.y = y;
    }
}
