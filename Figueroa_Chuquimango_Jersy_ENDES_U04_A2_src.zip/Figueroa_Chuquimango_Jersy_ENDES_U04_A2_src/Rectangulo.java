package figuras;

import java.awt.Color;

/**
 * Clase que representa un rectángulo.
 * 
 * @author JersyFigueroa
 */
public class Rectangulo extends Figura {

    /** Base */
    private double base;

    /** Altura */
    private double altura;

    /**
     * Constructor.
     * 
     * @param x centro X
     * @param y centro Y
     * @param color color
     * @param base base
     * @param altura altura
     */
    public Rectangulo(double x, double y, Color color, double base, double altura) {
        super(x, y, color);
        this.base = base;
        this.altura = altura;
    }

    /**
     * Calcula el área.
     */
    public double área() {
        return base * altura;
    }

    /**
     * Calcula el perímetro.
     */
    public double perímetro() {
        return 2 * (base + altura);
    }
}
