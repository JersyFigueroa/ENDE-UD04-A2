package figuras;

import java.awt.Color;

/**
 * Clase que representa un triángulo.
 * 
 * @author JersyFigueroa
 */
public class Triángulo extends Figura {

    private double lado1, lado2, lado3;

    /**
     * Constructor.
     */
    public Triángulo(double x, double y, Color color, double l1, double l2, double l3) {
        super(x, y, color);
        this.lado1 = l1;
        this.lado2 = l2;
        this.lado3 = l3;
    }

    /**
     * Calcula el perímetro.
     */
    public double perímetro() {
        return lado1 + lado2 + lado3;
    }

    /**
     * Calcula el área usando fórmula de Herón.
     */
    public double área() {
        double s = perímetro() / 2;
        return Math.sqrt(s * (s - lado1) * (s - lado2) * (s - lado3));
    }
}
